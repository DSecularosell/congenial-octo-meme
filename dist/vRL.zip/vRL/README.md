# Vapour, A Pastel Apocalypse

The year is 20xx, the world has devolved into nothing short of ruin. 

When they flipped the switch and booted up the "Holy Grail", we thought all of our problems were a thing of the past.


They were very, very wrong

Fight your way through hordes of ravenous Dorks and Lumpus' to pick up a sword and die, I guess. Have fun!

